import copy
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import uuid

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'try-omarchy/files/usr/lib/try-omarchy/managed-owner-setup'
loader = importlib.machinery.SourceFileLoader('managed_setup', str(LIB))
spec = importlib.util.spec_from_loader(loader.name, loader)
m = importlib.util.module_from_spec(spec); loader.exec_module(m)
CONTRACT = json.loads((ROOT / 'try-omarchy/files/usr/share/try-omarchy/owner-setup-contract.json').read_bytes())
LEAN = json.loads((ROOT / 'try-omarchy/files/usr/share/try-omarchy/lean-owner-setup-contract.json').read_bytes())
LEAN_A948D8A = json.loads((ROOT / 'try-omarchy/files/usr/share/try-omarchy/lean-owner-setup-contract-a948d8a.json').read_bytes())


BOOT = '33333333-3333-4333-8333-333333333333'


def command_line(manifest):
    return 'tryomarchy.managed_setup=1 tryomarchy.managed_setup_report=' + m.binding_digest(m.report_binding(manifest))


class ManagedSetupTests(unittest.TestCase):
    def fixture(self, digest=None):
        identity = str(uuid.uuid4()).upper()
        value = {'schemaVersion': 1, 'vmID': identity, 'sessionToken': str(uuid.uuid4()).upper(), 'fingerprint': 'a' * 64,
                 'hostname': 'work-' + identity[:8].lower(), 'configuration': {'username': 'owner', 'fullName': 'Synthetic Owner', 'email': 'owner@example.invalid', 'hostnamePrefix': 'work', 'timezone': 'UTC', 'keyboardID': 'English (US)'}}
        if digest is not None: value['ownerSetupContractSHA256'] = digest
        return value

    def test_selection_uses_only_packaged_reviewed_contracts(self):
        resources = ROOT / 'try-omarchy/files/usr/share/try-omarchy'
        for digest, name, expected in [(m.OFFICIAL, 'owner-setup-contract.json', CONTRACT), (m.LEAN, 'lean-owner-setup-contract.json', LEAN),
                                       (m.LEAN_A948D8A, 'lean-owner-setup-contract-a948d8a.json', LEAN_A948D8A)]:
            data = (resources / name).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), digest)
            with patch.object(m, 'reviewed_bytes', return_value=data):
                self.assertEqual(m.selected_contract(self.fixture(digest))[0], expected)
                with self.assertRaises(ValueError): m.selected_contract(self.fixture('a' * 64))
            with patch.object(m, 'reviewed_bytes', return_value=b'{}'):
                with self.assertRaises(ValueError): m.selected_contract(self.fixture(digest))
        self.assertEqual(CONTRACT['keyboards'], LEAN['keyboards'])
        # Omarchy 4.5 keeps every keyboard ID and changes only three console keymaps.
        self.assertEqual([k['id'] for k in CONTRACT['keyboards']], [k['id'] for k in LEAN_A948D8A['keyboards']])
        changed = {k['id']: k['keymap'] for k, old in zip(LEAN_A948D8A['keyboards'], LEAN['keyboards']) if k != old}
        self.assertEqual(changed, {'French': 'fr-latin1', 'French (Switzerland)': 'fr_CH-latin1', 'German': 'de-latin1'})
        self.assertEqual(sorted(adapter for _, adapter in m.CONTRACTS.values()), ['lean-a948d8a', 'lean-e4fffc6', 'official'])

    def test_programs_are_an_exact_set_and_reject_mixed_or_changed_bytes(self):
        for contract in (CONTRACT, LEAN, LEAN_A948D8A):
            with patch.object(m, 'reviewed_bytes', return_value=b'unknown\nmain\n'):
                with self.assertRaises(ValueError): m.verified_program(contract)
        original = b'#!/bin/bash\nmain\n'
        contract = {'schemaVersion': 1, 'programs': {str(m.PROGRAM): hashlib.sha256(original).hexdigest()}}
        with patch.object(m, 'reviewed_bytes', return_value=original):
            self.assertEqual(m.verified_program(contract)[str(m.PROGRAM)], original)
        for data in (b'changed\nmain\n', b'#!/bin/bash\nunknown\n'):
            with patch.object(m, 'reviewed_bytes', return_value=data):
                with self.assertRaises(ValueError): m.verified_program(contract)

    def test_regular_root_owned_unwritable_programs_and_parents_are_required(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory).resolve() / 'program'; path.write_bytes(b'program'); path.chmod(0o755)
            real_lstat = m.Path.lstat; real_fstat = m.os.fstat
            def root_info(value):
                return os.stat_result((value.st_mode, value.st_ino, value.st_dev, value.st_nlink, 0, value.st_gid, value.st_size, value.st_atime, value.st_mtime, value.st_ctime))
            def parent_stat(path):
                value = real_lstat(path)
                if stat.S_ISDIR(value.st_mode):
                    return os.stat_result((0o40755, value.st_ino, value.st_dev, value.st_nlink, 0, value.st_gid, value.st_size, value.st_atime, value.st_mtime, value.st_ctime))
                return value
            with patch.object(m.Path, 'lstat', parent_stat), patch.object(m.os, 'fstat', lambda fd: root_info(real_fstat(fd))):
                self.assertEqual(m.reviewed_bytes(path), b'program')
                path.chmod(0o777)
                with self.assertRaises(ValueError): m.reviewed_bytes(path)
                path.chmod(0o755); link = path.parent / 'link'; link.symlink_to(path)
                with self.assertRaises(OSError): m.reviewed_bytes(link)
                link.unlink(); os.link(path, link)
                with self.assertRaises(ValueError): m.reviewed_bytes(path)
                link.unlink()
            with self.assertRaises(ValueError): m.reviewed_bytes(path)

    def test_answers_validate_and_private_reader_refuses_unsafe_seeds(self):
        for contract in (CONTRACT, LEAN, LEAN_A948D8A):
            manifest = self.fixture()
            self.assertEqual(m.validate(manifest, {'password': 'synthetic-password'}, contract)['keymap'], 'us')
            for key, value in [('username', 'root'), ('username', 'owner;eval'), ('hostnamePrefix', '../bad'), ('timezone', '../../etc/passwd'), ('keyboardID', 'unknown'), ('fullName', 'line\nbreak')]:
                invalid = copy.deepcopy(manifest); invalid['configuration'][key] = value
                with self.assertRaises(ValueError): m.validate(invalid, {'password': 'synthetic-password'}, contract)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'seed'; path.write_bytes(b'synthetic'); path.chmod(0o600)
            self.assertEqual(m.read(path), b'synthetic')
            path.chmod(0o644)
            with self.assertRaises(ValueError): m.read(path)
            path.chmod(0o600)
            with self.assertRaises(ValueError): m.read(path, 2)

    def run_bash(self, root, kind, mode='success'):
        excerpt = (ROOT / 'tests/fixtures/owner-contracts' / (('lean' if kind.startswith('lean') else kind) + '.sh')).read_text()
        excerpt = excerpt.replace('/etc/vconsole.conf', str(root / 'vconsole')).replace('/etc/systemd/system', str(root / 'systemd'))
        script = root / 'source'
        script.write_text('''PROVISIONING_DIR=$FIXTURE
REKEY_STATE=$FIXTURE/luks-rekey.state
LOG_FILE=$FIXTURE/log
STATE_FILE=$FIXTURE/owner-state
FINALIZE_WARNING_FLAG=$FIXTURE/warning
''' + excerpt + '''
create_user() { printf '%s\n' "$username" >> "$FIXTURE/accounts"; printf %s "$username" >"$PROVISIONING_DIR/setup-user"; }
install_authorized_keys() { :; }; configure_login() { :; }; configure_hostname() { :; }; configure_timezone() { :; }
finalize_user() { [[ $MODE != warning ]]; }
luks_rekey_pending() { return 1; }; luks_staged_unlock_remains() { return 1; }; limine_entries_stale() { return 1; }
log_step() { :; }; platform_ready() { [[ $MODE != platform-failure ]]; }
omarchy_persist_input_selection() { printf '%s|%s' "$keyboard_input_method" "$keyboard_xkb_layout" >"$FIXTURE/input-method"; }
tty() { printf 'not-a-terminal'; }
localectl() { if [[ $MODE == keyboard-failure ]]; then return 1; fi; printf 'us\ncolemak\n'; }
systemd-firstboot() { printf 'KEYMAP=us\nXKBLAYOUT=us\n' >"$FIXTURE/vconsole"; }
systemctl() { :; }
usermod() { printf '%s\n' "$*" >"$FIXTURE/gecos"; }
getent() { printf 'owner:x:1000:1000::%s:/bin/bash\n' "$FIXTURE"; }
managed_commit() { [[ $MODE != commit-failure ]] || return 1; printf committed >"$FIXTURE/commit"; }
runuser() { printf '%s\n' "$*" >>"$FIXTURE/git"; }
''')
        if mode == 'interface': script.write_text(script.read_text() + '\nunset -f platform_ready\n')
        secret = "synthetic'$(touch " + str(root / 'injected') + '):password'
        values = ['owner', secret, 'Synthetic Owner', 'owner@example.invalid', 'work-12345678', 'UTC', 'English (US)', 'us', 'none', '']
        bash = m.BASH.replace('/usr/lib/try-omarchy/managed-owner-setup --commit', 'managed_commit')
        run = subprocess.run(['/bin/bash', '-c', bash, 'fixture', str(script), 'official' if kind == 'official' else ('lean-e4fffc6' if kind == 'lean' else kind)], input=b''.join(v.encode()+b'\0' for v in values), env=dict(os.environ, FIXTURE=str(root), MODE=mode), capture_output=True)
        self.assertFalse((root / 'injected').exists())
        self.assertNotIn(secret.encode(), run.stdout + run.stderr + (root / 'log').read_bytes())
        return run

    def test_reviewed_functions_keyboard_account_cleanup_warning_retry_and_interfaces(self):
        for kind in ('official', 'lean', 'lean-a948d8a'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as directory:
                root=Path(directory); (root/'pending').touch(); (root/'log').touch()
                result = self.run_bash(root, kind, 'warning')
                self.assertNotEqual(result.returncode, 0, result.stderr)
                self.assertTrue((root/'pending').exists()); self.assertEqual((root/'setup-user').read_text(), 'owner')
                result = self.run_bash(root, kind)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertFalse((root/'pending').exists()); self.assertFalse((root/'warning').exists())
                self.assertEqual((root/'accounts').read_text().splitlines(), ['owner', 'owner'])
                self.assertEqual((root/'input-method').read_text(), 'none|')
                if kind == 'lean':
                    self.assertIn('Synthetic Owner', (root/'gecos').read_text()); self.assertIn('owner@example.invalid', (root/'git').read_text())
            for mode in ('keyboard-failure', 'platform-failure', 'interface', 'commit-failure'):
                with tempfile.TemporaryDirectory() as directory:
                    root=Path(directory); (root/'pending').touch(); (root/'log').touch()
                    result = self.run_bash(root, kind, mode)
                    self.assertNotEqual(result.returncode, 0); self.assertTrue((root/'pending').exists())
                    self.assertEqual((root/'accounts').exists(), mode == 'commit-failure')

    def test_main_unknown_contract_and_failures_never_execute_unverified_fallback(self):
        for mode in ('contract', 'provision', 'success'):
            with tempfile.TemporaryDirectory() as directory:
                root=Path(directory); (root/'pending').touch()
                manifest=self.fixture(m.LEAN)
                for name,value in [('manifest.json',manifest),('owner-setup.json',{'password':'synthetic-password'})]:
                    p=root/name; p.write_text(json.dumps(value)); p.chmod(0o600)
                cmd=root/'cmdline'; cmd.write_text(command_line(manifest))
                result=type('Result',(),{'stdout':'disk'})()
                with patch.object(m,'SHARE',root),patch.object(m,'RUN',root),patch.object(m,'boot_id',return_value=BOOT),patch.object(m,'PENDING',root/'pending'),patch.object(m,'CMDLINE',cmd),patch.object(m,'IDENTITY',root/'identity'),patch.object(m,'mount_share'),patch.object(m,'directory'),patch.object(m,'selected_contract',side_effect=ValueError if mode=='contract' else None,return_value=(LEAN,'lean-e4fffc6')),patch.object(m,'verified_program',return_value={}),patch.object(m.subprocess,'run',return_value=result),patch.object(m.pwd,'getpwall',return_value=[]),patch.object(m,'status') as status,patch.object(m,'provision',side_effect=ValueError if mode=='provision' else None) as provision,patch.object(m,'matching_identity') as identity,patch.object(m,'cleanup_finished',return_value=True),patch.object(m,'report_completion',side_effect=lambda binding:m.status(dict(binding,configuration={'username':binding['owner']}),'configured')),patch.object(m.os,'execv') as execute:
                    self.assertEqual(m.main(),0 if mode=='success' else 1)
                    execute.assert_not_called()
                    if mode=='success': identity.assert_called_once_with(manifest); self.assertEqual(status.call_args.args[1:],('configured',))
                    else: identity.assert_not_called(); self.assertEqual(status.call_args.args[1:],('error','contract-mismatch' if mode=='contract' else 'provisioning-failed'))
                    self.assertEqual(provision.call_count,int(mode!='contract'))

    def test_unseeded_interactive_path_and_identity_bound_acknowledgement(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with patch.object(m,'CMDLINE',root/'missing'),patch.object(m.os,'execv',side_effect=SystemExit) as execute:
                with self.assertRaises(SystemExit): m.main()
                execute.assert_called_once_with(str(m.PROGRAM),[str(m.PROGRAM)])
            manifest=self.fixture(m.LEAN)
            identity={k:manifest[k] for k in ('vmID','fingerprint','ownerSetupContractSHA256')}; identity['owner']='owner'
            for name,value in [('manifest.json',manifest),('identity',identity)]:
                p=root/name;p.write_text(json.dumps(value));p.chmod(0o600)
            cmd=root/'cmdline';cmd.write_text(command_line(manifest))
            with patch.object(m,'SHARE',root),patch.object(m,'RUN',root),patch.object(m,'boot_id',return_value=BOOT),patch.object(m,'CMDLINE',cmd),patch.object(m,'PENDING',root/'pending'),patch.object(m,'IDENTITY',root/'identity'),patch.object(m,'mount_share'),patch.object(m,'directory'),patch.object(m,'selected_contract',return_value=(LEAN,'lean-e4fffc6')),patch.object(m.pwd,'getpwnam',return_value=type('Account',(),{'pw_uid':1000})()),patch.object(m,'status') as status:
                m.acknowledge();self.assertEqual(status.call_args.args[1:],('configured',))
                manifest['ownerSetupContractSHA256']=m.OFFICIAL;(root/'manifest.json').write_text(json.dumps(manifest))
                with self.assertRaises(ValueError):m.acknowledge()

class SnapshotTests(unittest.TestCase):
    fixture = ManagedSetupTests.fixture
    def test_snapshot_sources_and_secret_transport_are_bound_and_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            program = b'#!/bin/bash\nsource "$OMARCHY_PATH/install/provisioning/setup-form.sh"\nmain\n'
            programs = {str(m.PROGRAM): program, '/usr/share/omarchy/install/provisioning/setup-form.sh': b'# synthetic form\n'}
            secret = "synthetic'$(never-execute)password"
            with patch.object(m, 'RUN', Path(directory)), patch.object(m.subprocess, 'run') as run:
                m.provision(self.fixture(), {'password': secret}, CONTRACT['keyboards'][0], programs, 'official')
                args, kwargs = run.call_args
                self.assertNotIn(secret, ' '.join(args[0]))
                self.assertIn(secret.encode() + b'\0', kwargs['input'])
                self.assertEqual(list(Path(directory).iterdir()), [])
                programs[str(m.PROGRAM)] = b'#!/bin/bash\nmain\n'
                with self.assertRaises(ValueError): m.provision(self.fixture(), {'password': secret}, CONTRACT['keyboards'][0], programs, 'official')
                self.assertEqual(run.call_count, 1)

    def test_lean_finalizer_executes_the_canonical_hash_checked_path(self):
        with tempfile.TemporaryDirectory() as directory:
            program = b'#!/bin/bash\nfinalize_user() { "$OMARCHY_PATH/bin/omarchy-provision-user" --force --first-install; }\nmain\n'
            programs = {str(m.PROGRAM): program, '/usr/bin/omarchy-provision-user': b'# synthetic checked finalizer\n'}
            def execute(args, **kwargs):
                source = Path(args[-2]).read_text()
                self.assertIn('/usr/bin/omarchy-provision-user --force --first-install', source)
                self.assertNotIn('$OMARCHY_PATH/bin/omarchy-provision-user', source)
            for digest, contract, adapter in ((m.LEAN, LEAN, 'lean-e4fffc6'), (m.LEAN_A948D8A, LEAN_A948D8A, 'lean-a948d8a')):
                programs[str(m.PROGRAM)] = program
                with self.subTest(adapter=adapter), patch.object(m,'RUN',Path(directory)),patch.object(m.subprocess,'run',side_effect=execute) as run:
                    m.provision(self.fixture(digest), {'password':'synthetic-password'}, contract['keyboards'][0], programs, adapter)
                    programs[str(m.PROGRAM)] = b'#!/bin/bash\nmain\n'
                    with self.assertRaises(ValueError): m.provision(self.fixture(digest), {'password':'synthetic-password'}, contract['keyboards'][0], programs, adapter)
                    self.assertEqual(run.call_count,1)

class CompletionBoundaryTests(unittest.TestCase):
    fixture = ManagedSetupTests.fixture
    def test_commit_precedes_cleanup_and_restarts_acknowledge_the_bound_owner(self):
        for digest in (m.OFFICIAL,m.LEAN,m.LEAN_A948D8A):
            with self.subTest(digest=digest),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);manifest=self.fixture(digest)
                (root/'manifest.json').write_text(json.dumps(manifest));(root/'manifest.json').chmod(0o600)
                pending=root/'pending';pending.touch();resume=root/'setup-user';resume.write_text('owner')
                cmd=root/'cmdline';cmd.write_text(command_line(manifest))
                account=type('Account',(),{'pw_uid':1000})()
                with patch.object(m,'SHARE',root),patch.object(m,'RUN',root),patch.object(m,'boot_id',return_value=BOOT),patch.object(m,'IDENTITY',root/'identity'),patch.object(m,'PENDING',pending),patch.object(m,'CMDLINE',cmd),patch.object(m,'directory'),patch.object(m,'mount_share'),patch.object(m,'directory'),patch.object(m,'selected_contract',return_value=(CONTRACT,'official')),patch.object(m.pwd,'getpwnam',return_value=account),patch.object(m,'status') as status:
                    real_fsync = os.fsync
                    directory_flushes = []
                    def durable(fd):
                        if stat.S_ISDIR(os.fstat(fd).st_mode):
                            directory_flushes.append(fd)
                            if len(directory_flushes) == 1: raise OSError('synthetic directory flush failure')
                        return real_fsync(fd)
                    with patch.object(m.os,'fsync',side_effect=durable):
                        with self.assertRaises(OSError): m.commit_identity()
                        m.commit_identity()
                    self.assertGreaterEqual(len(directory_flushes),2)
                    self.assertTrue(pending.exists());self.assertEqual(json.loads(m.read(root/'identity')),m.identity_value(manifest))
                    m.matching_identity(manifest)
                    m.commit_identity()  # Idempotent after interruption before cleanup.
                    changed=copy.deepcopy(manifest);changed['fingerprint']='b'*64
                    with self.assertRaises(ValueError):m.matching_identity(changed)
                    pending.unlink()
                    with self.assertRaises(ValueError):m.acknowledge()  # Partial cleanup cannot report success.
                    resume.unlink()
                    m.acknowledge();self.assertEqual(status.call_args.args[1:],('configured',))
                    with self.assertRaises(ValueError):m.commit_identity()  # Not an arbitrary completion override.

class RetryIdentityTests(unittest.TestCase):
    fixture = ManagedSetupTests.fixture
    def test_matching_committed_identity_can_retry_after_interrupted_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);manifest=self.fixture(m.LEAN)
            for name,value in [('manifest.json',manifest),('owner-setup.json',{'password':'synthetic-password'}),('identity',m.identity_value(manifest))]:
                path=root/name;path.write_text(json.dumps(value));path.chmod(0o600)
            pending=root/'pending';pending.touch();resume=root/'setup-user';resume.write_text('owner')
            cmd=root/'cmdline';cmd.write_text(command_line(manifest))
            account=type('Account',(),{'pw_name':'owner','pw_uid':1000,'pw_shell':'/bin/bash'})()
            def provision(*args):pending.unlink();resume.unlink()
            with patch.object(m,'SHARE',root),patch.object(m,'RUN',root),patch.object(m,'boot_id',return_value=BOOT),patch.object(m,'IDENTITY',root/'identity'),patch.object(m,'PENDING',pending),patch.object(m,'CMDLINE',cmd),patch.object(m,'mount_share'),patch.object(m,'directory'),patch.object(m,'selected_contract',return_value=(LEAN,'lean-e4fffc6')),patch.object(m,'verified_program',return_value={}),patch.object(m,'reviewed_bytes',return_value=b'owner'),patch.object(m.pwd,'getpwall',return_value=[account]),patch.object(m.pwd,'getpwnam',return_value=account),patch.object(m.subprocess,'run',return_value=type('Result',(),{'stdout':'disk'})()),patch.object(m,'provision',side_effect=provision) as attempt,patch.object(m,'status') as status:
                self.assertEqual(m.main(),0);attempt.assert_called_once()
                self.assertEqual(status.call_args.args[1:],('configured',))

if __name__ == '__main__': unittest.main()
