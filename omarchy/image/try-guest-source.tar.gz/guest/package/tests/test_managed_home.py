import importlib.machinery
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock
import uuid

SOURCE = Path(__file__).resolve().parents[1] / 'try-omarchy/files/usr/lib/try-omarchy/managed-home'
loader = importlib.machinery.SourceFileLoader('managed_home', str(SOURCE))
spec = importlib.util.spec_from_loader(loader.name, loader)
module = importlib.util.module_from_spec(spec)
loader.exec_module(module)

class HomeDiskTests(unittest.TestCase):
    def test_owner_and_disk_identity_must_match(self):
        disk = str(uuid.uuid4())
        owner = SimpleNamespace(pw_name='owner', pw_uid=1000, pw_gid=1000)
        record = dict(schemaVersion=1, id=disk, owner='owner', uid=1000, gid=1000)
        module.verify_record(record, disk, owner)
        for key, value in [('id', str(uuid.uuid4())), ('uid', 1001), ('gid', 1001), ('owner', 'other'), ('schemaVersion', 2)]:
            with self.assertRaises(ValueError): module.verify_record(dict(record, **{key:value}), disk, owner)

    def test_single_disk_boot_is_noop_but_an_unconfigured_device_is_refused(self):
        with tempfile.TemporaryDirectory() as scratch:
            device = Path(scratch) / 'device'
            with mock.patch.object(module, 'DEVICE', device), mock.patch.dict(module.os.environ, {'CREDENTIALS_DIRECTORY': scratch}):
                module.main()
                device.touch()
                with self.assertRaises(ValueError): module.main()

    def test_mount_and_login_order_and_no_automatic_reformat(self):
        files = SOURCE.parents[1]
        unit = (files/'systemd/system/try-omarchy-home.service').read_text()
        self.assertIn('omarchy-provision-owner.service', unit)
        self.assertIn('Before=display-manager.service', unit)
        self.assertIn('ImportCredential=tryomarchy.home', unit)
        source=SOURCE.read_text()
        self.assertIn('OMARCHY_HOME_FORMATTING_V1', source)
        self.assertIn('unrecognized-blank-disk', source)
        self.assertLess(source.index('OMARCHY_HOME_FORMATTING_V1'), source.index("run(['/usr/bin/mkfs.ext4'"))
        self.assertIn('if fresh:', source)
        self.assertNotIn('mkfs.ext4\', \'-F', source)

if __name__ == '__main__': unittest.main()
