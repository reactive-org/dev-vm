import copy
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from contextlib import ExitStack, contextmanager
from types import SimpleNamespace
from unittest.mock import patch
import uuid
import test_managed_setup as setup_tests
from test_managed_setup import m, ROOT, CONTRACT, LEAN


@contextmanager
def fixture(digest):
    with tempfile.TemporaryDirectory(prefix='owner-report-timer-') as directory, ExitStack() as stack:
        root = Path(directory)
        share, run, persistent, provisioning = [root / name for name in ('share', 'run', 'identity', 'provisioning')]
        for path in (share, run, persistent, provisioning): path.mkdir(mode=0o700)
        manifest = setup_tests.ManagedSetupTests().fixture(digest)
        for name, value in [('manifest.json', manifest), ('owner-setup.json', {'password': 'synthetic-secret-password'})]:
            path = share / name; path.write_text(json.dumps(value)); path.chmod(0o600)
        marker = root / 'launch.json'; marker.write_text(json.dumps(manifest)); marker.chmod(0o600)
        cmdline = root / 'cmdline'
        cmdline.write_text('tryomarchy.managed_setup=1 tryomarchy.managed_setup_report=' + m.binding_digest(m.report_binding(manifest)))
        boot = root / 'boot-id'; boot.write_text(str(uuid.uuid4()))
        pending = provisioning / 'pending'; pending.touch()
        warning = root / 'warning'
        contracts = {m.OFFICIAL: (ROOT / 'try-omarchy/files/usr/share/try-omarchy/owner-setup-contract.json', 'official'),
                     m.LEAN: (ROOT / 'try-omarchy/files/usr/share/try-omarchy/lean-owner-setup-contract.json', 'lean-e4fffc6')}
        def private(path): path.mkdir(mode=0o700, exist_ok=True, parents=True)
        for name, value in dict(SHARE=share, RUN=run, IDENTITY=persistent/'identity.json', PENDING=pending, CMDLINE=cmdline, BOOT_ID=boot, CONTRACTS=contracts).items():
            stack.enter_context(patch.object(m, name, value))
        stack.enter_context(patch.object(m, 'directory', side_effect=private))
        stack.enter_context(patch.object(m, 'mount_share'))
        stack.enter_context(patch.object(m, 'reviewed_bytes', side_effect=lambda path, **kwargs: Path(path).read_bytes()))
        stack.enter_context(patch.object(m.pwd, 'getpwnam', return_value=SimpleNamespace(pw_uid=1000)))
        original_cleanup = m.cleanup_finished
        stack.enter_context(patch.object(m, 'cleanup_finished', side_effect=lambda: original_cleanup() and not warning.exists()))
        yield SimpleNamespace(root=root, share=share, run=run, manifest=manifest, marker=marker, pending=pending, boot=boot, warning=warning, cmdline=cmdline)


def completed(f):
    m.commit_identity()
    f.pending.unlink()
    m.acknowledge()


def host_cleanup(f):
    for path in [f.share/'owner-setup.json', f.share/'manifest.json', f.marker]: path.unlink()


class OwnerReportTimerTests(unittest.TestCase):
    def test_completion_host_cleanup_and_repeated_timer_reports_for_both_contracts(self):
        for digest in (m.OFFICIAL, m.LEAN):
            with self.subTest(contract=digest), fixture(digest) as f:
                completed(f)
                before = (f.run/'status.json').read_bytes()
                host_cleanup(f)
                for _ in range(4):
                    m.acknowledge()
                    self.assertEqual((f.run/'status.json').read_bytes(), before)
                receipt = f.run/m.REPORT_NAME
                self.assertEqual(stat.S_IMODE(receipt.stat().st_mode),0o600)
                self.assertNotIn('synthetic-secret-password',receipt.read_text())
                self.assertNotIn('configuration',receipt.read_text())
                self.assertEqual(list(f.share.iterdir()),[])

    def test_timer_racing_host_manifest_unlink_uses_only_validated_receipt(self):
        for digest in (m.OFFICIAL,m.LEAN):
            with self.subTest(contract=digest),fixture(digest) as f:
                completed(f)
                original=m.read
                def racing_read(path,*args,**kwargs):
                    if path==f.share/'manifest.json':
                        host_cleanup(f)
                        raise FileNotFoundError('synthetic host cleanup race')
                    return original(path,*args,**kwargs)
                with patch.object(m,'read',side_effect=racing_read):m.acknowledge()
                self.assertEqual(json.loads((f.run/'status.json').read_bytes())['state'],'configured')

    def test_wrong_vm_session_owner_fingerprint_contract_and_schema_are_rejected(self):
        for digest in (m.OFFICIAL,m.LEAN):
            for field,value in [('vmID',str(uuid.uuid4()).upper()),('sessionToken',str(uuid.uuid4()).upper()),('owner','another'),('fingerprint','b'*64),('ownerSetupContractSHA256',m.LEAN if digest==m.OFFICIAL else m.OFFICIAL),('ownerSetupContractSHA256','c'*64),('schemaVersion',True)]:
                with self.subTest(contract=digest,field=field),fixture(digest) as f:
                    completed(f);host_cleanup(f)
                    path=f.run/m.REPORT_NAME;receipt=json.loads(path.read_bytes());receipt['binding'][field]=value;path.write_text(json.dumps(receipt))
                    before=(f.run/'status.json').read_bytes()
                    with self.assertRaises((ValueError,TypeError,KeyError)):m.acknowledge()
                    self.assertEqual((f.run/'status.json').read_bytes(),before)

    def test_committed_identity_cannot_change_vm_owner_fingerprint_or_contract(self):
        for digest in (m.OFFICIAL,m.LEAN):
            for field,value in [('vmID',str(uuid.uuid4()).upper()),('owner','another'),('fingerprint','b'*64),('ownerSetupContractSHA256',m.LEAN if digest==m.OFFICIAL else m.OFFICIAL)]:
                with self.subTest(contract=digest,field=field),fixture(digest) as f:
                    completed(f);host_cleanup(f)
                    identity=json.loads(m.IDENTITY.read_bytes());identity[field]=value;m.IDENTITY.write_text(json.dumps(identity))
                    with self.assertRaises(ValueError):m.acknowledge()

    def test_old_boot_and_new_session_credentials_cannot_reuse_receipt(self):
        for digest in (m.OFFICIAL,m.LEAN):
            for mode in ('boot','session','missing','duplicate'):
                with self.subTest(contract=digest,mode=mode),fixture(digest) as f:
                    completed(f);host_cleanup(f)
                    if mode=='boot':f.boot.write_text(str(uuid.uuid4()))
                    if mode=='session':
                        other=copy.deepcopy(f.manifest);other['sessionToken']=str(uuid.uuid4()).upper()
                        f.cmdline.write_text('tryomarchy.managed_setup=1 tryomarchy.managed_setup_report='+m.binding_digest(m.report_binding(other)))
                    if mode=='missing':f.cmdline.write_text('tryomarchy.managed_setup=1')
                    if mode=='duplicate':f.cmdline.write_text(f.cmdline.read_text()+' '+f.cmdline.read_text().split()[-1])
                    with self.assertRaises(ValueError):m.acknowledge()

    def test_damaged_identity_receipt_missing_receipt_and_unsafe_files_fail_closed(self):
        for digest in (m.OFFICIAL,m.LEAN):
            for mode in ('identity','receipt','missing-receipt','permissions','symlink','hardlink'):
                with self.subTest(contract=digest,mode=mode),fixture(digest) as f:
                    completed(f);host_cleanup(f);path=f.run/m.REPORT_NAME
                    if mode=='identity':m.IDENTITY.write_text('{}')
                    elif mode=='receipt':path.write_text('broken')
                    elif mode=='missing-receipt':path.unlink()
                    elif mode=='permissions':path.chmod(0o644)
                    elif mode=='hardlink':os.link(path,f.run/'outside-link')
                    else:
                        held=f.run/'held';path.rename(held);path.symlink_to(held)
                    with self.assertRaises((ValueError,OSError,KeyError)):m.acknowledge()

    def test_incomplete_cleanup_and_warning_never_publish_configured(self):
        for digest in (m.OFFICIAL,m.LEAN):
            for name in ('pending','setup-user','authorized_keys','luks-rekey.state','warning'):
                with self.subTest(contract=digest,marker=name),fixture(digest) as f:
                    completed(f);host_cleanup(f)
                    path=f.warning if name=='warning' else f.pending.parent/name;path.touch()
                    with patch.object(m,'status') as status:
                        if name=='pending':m.acknowledge()
                        else:
                            with self.assertRaises(ValueError):m.acknowledge()
                        status.assert_not_called()

    def test_interrupted_receipt_commit_keeps_pending_and_cannot_publish_success(self):
        for digest in (m.OFFICIAL,m.LEAN):
            with self.subTest(contract=digest),fixture(digest) as f:
                actual=m.os.fsync
                def flush(fd):
                    if stat.S_ISDIR(os.fstat(fd).st_mode) and os.fstat(fd).st_ino==f.run.stat().st_ino:raise OSError('synthetic report flush failure')
                    return actual(fd)
                with patch.object(m.os,'fsync',side_effect=flush),patch.object(m,'status') as status:
                    with self.assertRaises(OSError):m.commit_identity()
                    self.assertTrue(f.pending.exists());m.acknowledge();status.assert_not_called()
                m.commit_identity();f.pending.unlink();m.acknowledge();host_cleanup(f);m.acknowledge()

    def test_retained_manifest_is_checked_and_not_ignored_when_damaged(self):
        for digest in (m.OFFICIAL,m.LEAN):
            with self.subTest(contract=digest),fixture(digest) as f:
                completed(f);f.share.joinpath('manifest.json').write_text('{}')
                with self.assertRaises((ValueError,KeyError)):m.acknowledge()

    def test_digest_matches_helper_golden_vector(self):
        manifest=setup_tests.ManagedSetupTests().fixture(m.OFFICIAL)
        manifest.update(vmID='11111111-1111-4111-8111-111111111111',sessionToken='22222222-2222-4222-8222-222222222222',fingerprint='a'*64)
        self.assertEqual(m.binding_digest(m.report_binding(manifest)),'0ac533376504c0de084483efbf7551061ac7cad0eb857f178e1ecc2f236b7c9a')

if __name__=='__main__':unittest.main()
