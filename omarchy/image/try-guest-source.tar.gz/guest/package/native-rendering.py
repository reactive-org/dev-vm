#!/usr/bin/env python3
import hashlib
from pathlib import Path
import re
import sys


def prepare(recipe):
    recipe = Path(recipe)
    files = recipe / 'files'
    policy = files / 'usr/share/try-omarchy/hyprland.lua'
    if hashlib.sha256(policy.read_bytes()).hexdigest() != '1e775d3d25f9f201bb17b36a65d695b77500596142a0b1480bb8da863dea7f34':
        raise ValueError('Unreviewed Hyprland rendering policy')
    text = policy.read_text()
    before = 'if host_option("omarchy.qemu_virgl=1") then\n'
    if text.count(before) != 1:
        raise ValueError('Rendering policy changed')
    policy.write_text(text.replace(before, before + '  -- Preserve alpha-capable VirGL DMA-BUF formats on Hyprland 0.57.\n  hl.config({ quirks = { skip_non_kms_dmabuf_formats = false } })\n'))
    pkgbuild = recipe / 'PKGBUILD'
    text = pkgbuild.read_text()
    if len(re.findall(r'^pkgrel=\d+$', text, re.MULTILINE)) != 1:
        raise ValueError('Unsupported package release')
    pkgbuild.write_text(re.sub(r'^(pkgrel=\d+)$', r'\1.1', text, flags=re.MULTILINE))
    environment = files / 'usr/lib/environment.d/90-try-omarchy.conf'
    text = environment.read_text()
    if text.count('WLR_RENDERER_ALLOW_SOFTWARE=1\n') != 1:
        raise ValueError('Software rendering policy changed')
    environment.write_text(text.replace('WLR_RENDERER_ALLOW_SOFTWARE=1\n', ''))
    for relative in (
        'usr/lib/try-omarchy/bin/ghostty', 'usr/lib/try-omarchy/bin/kitty',
        'usr/lib/systemd/user/app-com.mitchellh.ghostty.service.d/10-try-omarchy-software-gl.conf',
        'usr/share/try-omarchy/ghostty/com.mitchellh.ghostty.desktop',
        'usr/share/libalpm/hooks/try-omarchy-ghostty.hook',
        'usr/share/libalpm/hooks/try-omarchy-ghostty-remove.hook',
    ):
        path = files / relative
        if not path.is_file() or path.is_symlink():
            raise ValueError('Integration layout changed')
        path.unlink()


if __name__ == '__main__':
    prepare(sys.argv[1])
